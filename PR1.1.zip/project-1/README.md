<h1>Instructions for building and running the program</h1>
Run main.py in the command line with the following format: <br>
- python3 main.py [input_file.txt] [output_file.txt]
